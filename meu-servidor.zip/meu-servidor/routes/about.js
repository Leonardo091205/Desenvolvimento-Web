
const aboutRoute = (req, res) => {
    res.statusCode = 200; // C�digo de status 200 OK
    res.setHeader('Content-Type', 'text/html');
    res.end('<h1>Sobre</h1><p>Esta � uma p�gina sobre o servidor.</p>');
};

module.exports = aboutRoute; // Exporta a fun��o para uso no servidor