 Página inicial
 curl http://127.0.0.1:8080/
 Página sobre
 curl http://127.0.0.1:8080/sobre
 Página receber dados
 curl -X POST http://127.0.0.1:8080/dados -d
 Página upload
 curl -X POST http://127.0.0.1:8080/upload -F 